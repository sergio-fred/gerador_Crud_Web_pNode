const express = require('express');
const session = require('express-session');
const fs = require('fs-extra');
const flash = require("connect-flash");
const app = express();
const sqlite = require("sqlite3");
const db = new sqlite.Database("./db/usuario.db");
const admz = require('adm-zip');

app.use(express.urlencoded({extended: false}));  
app.set('view engine', 'ejs');

//VARIAVEIS GLOBAIS
global.ema = ''; // email usuário
global.projeto = '';  //nome da projeto
global.aplicacao = ''; //nome da App
global.bdados=''; //nome do BD 
global.tabMestre=''; //tabela mestre
global.tabDetalhe=''; //tabela detalhes
global.from_fk = ''; //nome tabela que referencia (fk)
global.table_pk = ''; //nome tabela referenciada (pk)
global.to_pk = ''; //id da tabela referenciada (pk)
global.tmestre = []; //dataset da tab mestre
global.tdetalhes = []; //dataset da tab mestre
global.mestrePk = ''; //chave primaria a tab mestre
global.detalhePk= ''; //chave primaria a tab detalhe

//declaracao dos módulos para gravar Ejs
const tabelas = require('./tabelas.js');
const f_app = require('./f_app.js');
const f_index = require('./f_index.js');
const f_editar = require('./f_editar.js');
const f_inserirm = require('./f_inserirm.js');
const f_inserird = require('./f_inserird.js');
const f_delete = require('./f_delete.js');

// salvar bd no servidor usando multer
const multer = require('multer');
// declara diretorio padrão uploads
const storage = multer.diskStorage({ 
  //VER LOCAL ONDE EH GRAVADO BD (diferenca no servidor kinghost)
  //antes: 'apps/'+projeto+'/'
   destination: (req, file, cb) => {cb(null, 'apps/'+projeto+'/')}, //mesmo valor da linha 84 ('file')?????
   filename: (req, file, cb) => {cb(null, file.originalname)},
 });
 const upload = multer ({storage: storage});

 
app.use(session({ 
  secret: 'secret',
  cookie: { maxAge: 60000 },
  resave: true,
  saveUninitialized: true,
}));
app.use(flash());

app.get('/', function (req, res) {
      const sql = "SELECT * FROM users";
      db.all(sql, [], function (err, rows) {
        if (err) {
          return console.error(err.message);
        }
          res.render("index", { dados: rows });
      });
 });

app.post('/login', function (req, res) {
  //prepara variaveis para o nome do PROJETO
  let date_ob = new Date();
  let c = date_ob.getSeconds();
  let d = date_ob.getMilliseconds();
  let e = c+d; //gera randomico para nome projeto, baseado em segundos
  //const ema = req.body.email;
  ema = req.body.email;
  projeto = ema.substring(0,5);
  projeto = projeto+e; //nome definitivo de projetoN (N=1,2,3,...) 
  
// declara diretorio padrão uploads
const storage = multer.diskStorage({ 
  //VER LOCAL ONDE EH GRAVADO BD (diferenca no servidor kinghost)
   destination: (req, file, cb) => {cb(null, 'apps/'+projeto+'/')}, //mesmo valor da linha 84 ('file')?????
   filename: (req, file, cb) => {cb(null, file.originalname)},
 });
 global.upload = multer ({storage: storage});
   
  const pas = req.body.password;
  const query = [ema, pas];
  const sql = "SELECT id,email,password FROM users WHERE (email=?) and (password=?)";
  db.get(sql, query, function (err, row) {
    if (row === undefined) {
        req.flash('msg', "Usuário NÃO LOGADO...");
        res.locals.message = req.flash();
        res.render('logout.ejs', {});
    } else {
          req.flash('msg', "Escolha o BD e o nome da Aplicação...");
          res.locals.message = req.flash();
          res.render('login', {
          email: ema, 
          dados: row,
          projeto: projeto
          });
          req.session.email = ema;
          var dir = './apps/'+projeto;
          fs.mkdirSync(dir); //grava o diretório da App
    }    
 });
});

//rotas salvar bd com multer e reconhecer esquema do BD
app.post('/carrega', upload.single('file'), function (req, res, next) {
  bdados = req.body.bdados;
  aplicacao = projeto;
  
 //para verificar se o projeto já existe e emitir mensagem 
 // if (fs.existsSync("./"+projeto)) { 
    //mensagem aqui
 // } 
 
  const db_sql = new sqlite.Database("./apps/"+projeto+"/"+bdados); 

  // sql para mostrar em Ejs a instrucao Create das tabelas referenciadas
  const sql1 = "SELECT sql FROM sqlite_master where type ='table' and name<>'sqlite_sequence'";
    db_sql.all(sql1, [], function(err, query1) { 
  //dataset com nome das tabelas mestre e detalhes
  const sql2 = "SELECT name FROM sqlite_master WHERE type ='table' AND name NOT LIKE 'sqlite_%'";
    db_sql.all(sql2, [], function(err, query2) {
    tabMestre = query2[0].name;
    tabDetalhe = query2[1].name;
   
  //dataset com campos da tabela que referencia (pk)   
  const sql3 ="SELECT * FROM pragma_foreign_key_list(?)";
    db_sql.all(sql3, query2[1].name, function(err, query3) { 
      from_fk = query3[0].from;
      table_pk = query3[0].table;
      to_pk = query3[0].to;
       
  //dataset com campos, nome e pk da tabela mestre 
  const sql4 = "SELECT cid, name, pk FROM pragma_table_info(?)"; //estrutura da tabela Mestre
    db_sql.all(sql4, query2[0].name, function(err, query4) {
      tmestre = query4;
      chaveMestre_pk();
     
   //dataset com campos, nome e pk da tabela detalhes     
  const sql5 = "SELECT cid, name, pk FROM pragma_table_info(?)"; //estrutura da tabela Detalhes
    db_sql.all(sql5, query2[1].name, function(err, query5) {
      tdetalhes = query5;
      chaveDetalhes_pk();
      
      req.flash('msg', "Estrutura do BD SQLite em tabelas mestre-detalhes.");
      res.locals.message = req.flash();
      res.render('logado.ejs', {
        projeto: projeto,  //nome da aplicação/projeto
        bdados: bdados,    //nome do BD 
        criaTabelas: query1,  
        Tabelas: query2,
        Col: query3,
        Mestre: query4,
        Detalhes: query5,
      });
    });
   });
  });
 });

 });
 tabelas.mostraTabelas();  //chama função externa
 setTimeout(codigoEjs, 7000); //espera 7 seg para executar função de Ejs
}); //fim do app.post() /carrega


//sair do App e encerrar sessao
app.get('/logout', function (req,res) {
  console.log("logout e destroi session");
  req.session.destroy(function (err) {
    res.redirect('/'); 
   });
})

// ROTAS para /routes
//app.use('/', require('./routes/carregabd'));

// rota para zip e download do projeto
app.get('/downlo',function(req,res){
  var zp = new admz();
  zp.addLocalFolder(__dirname+'/'+'apps/'+aplicacao);
  const projeto_crud = aplicacao+'.zip';
  const data = zp.toBuffer();
  res.set('Content-Type','application/octet-stream');
	res.set('Content-Disposition',`attachment; filename=${projeto_crud}`);
	res.set('Content-Length',data.length);
	res.send(data);
})

//chama funcoes para alimentar .ejs e .js
function codigoEjs() {
  f_app.fApp(bdados,tabMestre,tabDetalhe,from_fk,to_pk,tmestre,tdetalhes,mestrePk,detalhePk); //chama função gravar ./app.js
  f_index.funcIndex(tmestre, tdetalhes);
  f_inserirm.fInserirm(tmestre,tdetalhes,mestrePk);
  f_inserird.fInserird(tmestre,tdetalhes,mestrePk,detalhePk);
  f_editar.fEditar(mestrePk,detalhePk,tmestre,tdetalhes);
  f_delete.fDelete(detalhePk,tmestre,tdetalhes);   
}

function chaveMestre_pk() {
  for (let i=0; i < tmestre.length; i++) { //busca pk tabela mestre
    if (tmestre[i].pk == 1) mestrePk = tmestre[i].name;
  }  
}

function chaveDetalhes_pk() {
  for (let i=0; i < tdetalhes.length; i++) { //busca pk tabela mestre
    if (tdetalhes[i].pk == 1) detalhePk = tdetalhes[i].name;
  }  
}

//instancia servidor (em kinghost: 21145)
app.listen(21145), () => {
//app.listen(3000, () => {
  console.log('Servidor ativo...');
});

