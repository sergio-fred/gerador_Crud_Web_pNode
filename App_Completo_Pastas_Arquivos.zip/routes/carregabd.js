//carregabd.js
var express = require('express');
var router = express.Router();
const sqlite = require("sqlite3");
//const db = new sqlite.Database("./usuario.db");
const path = require('path');

// salvar bd no servidor
const multer = require('multer');
//const flash = require('express-flash');
const storage = multer.diskStorage({
  destination: (req, file, cb) => {cb(null, 'uploads/')},
  filename: (req, file, cb) => {cb(null, file.originalname)},
 
 });
const upload = multer ({storage: storage});
// fim salvar bd


router.get('/login', function (req, res ) {
   res.render('login', {message: req.flash('message')})
});

//rota salvar bd com multer e reconhecer esquema do BD
router.post('/carrega5', upload.single('file'), function (req, res, next) {
  let bdados = req.body.bdados;
  const db_sql = new sqlite.Database("./uploads/"+bdados);

  db_sql.serialize(function() {
  db_sql.all("SELECT sql from sqlite_master where type ='table' and name<>'sqlite_sequence'", function(err, rows) {
  /*  rows.forEach(function (row) {
        console.log(row.sql);
  }); */
  //});
  db_sql.all("SELECT name FROM sqlite_master WHERE type ='table' AND name NOT LIKE 'sqlite_%'", function(err, rows2) {
    /*      rows2.forEach(function (row2) {
              console.log(row2.name);
              res.render('login', {tabelas: row, colunas: row2})
  }); */
  console.log(rows);
  console.log(rows2);
  //res.render('login', {tabelas: dadot});

  });

});
});
});


module.exports = router;