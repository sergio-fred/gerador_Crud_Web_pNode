const express = require("express");  
 const app = express();   
 const sqlite = require("sqlite3");   
 const db = new sqlite.Database("./bd_mestre_detalhes.db ");   
 app.use(express.urlencoded({extended: false}));   
 app.set("engine ejs", "ejs");   
     
 // (1)consulta todos regitros para index.ejs   
 app.get("/", function (req, res) {   
 const sql = "SELECT * FROM tabela_mestre, tabela_detalhes WHERE ID_mestre=FK_detalhe ORDER BY ID_mestre desc";   
 db.all(sql, [], function (err, rows) {     
     if (err) {     
   return console.error(err.message);     
     }     
     res.render("index.ejs", { dados: rows });     
   });     
 });     
 //inserir novo registro para inserirM.ejs    
        
 // (2)GET /inserir    
 app.get("/inserirM", function (req, res) {    
     res.render("inserirM.ejs", { dados: {} });    
   })    
        
 // POST /inserir    
 app.post("/inserirM", function (req, res) {    
  const sql1 = "INSERT INTO tabela_mestre (Campo_mestre1,Campo_mestre2) VALUES (  ?, ? )";  
  const dadosMestre = [req.body.Campo_mestre1,req.body.Campo_mestre2, ];  
 db.run(sql1, dadosMestre, function (err) {    
 if (err) {    
 return console.error(err.message);    
 }    
 });    
 // SELECT Tabela_mestre para recuperar ID_mestre para relacionamento    
 FK = "";   
 const sql2 = "SELECT * FROM tabela_mestre ORDER BY ID_mestre DESC limit 1";    
 db.all(sql2, [], function (err, rows) {    
 if (err) {    
 return console.error(err.message);    
 }    
 FK =  rows[0].ID_mestre;    
    
 //INSERT Tabela_detalhes    
  let sql3 = "INSERT INTO tabela_detalhes (Atributo_detalhe1,Atributo_detalhe2,FK_detalhe) VALUES (  ?, ?, ? )";  
  const dadosDetalhe = [req.body.Atributo_detalhe1,req.body.Atributo_detalhe2,FK, ];  
 db.run(sql3, dadosDetalhe, function (err) {    
   if (err) {    
     return console.error(err.message);    
   }    
   res.redirect("/");    
 });    
 });    
 });    
        
 // (3)GET /edit/id     
 app.get("/editar/:id_m/:id_d", function (req, res) {     
     const idm = req.params.id_m;     
     const idd = req.params.id_d;     
  const query = [idm, idd];     
 const sql = "SELECT * FROM tabela_mestre, tabela_detalhes WHERE (ID_mestre=FK_detalhe) and (ID_mestre =?) and (ID_detalhe =?)";     
 db.get(sql, query, function (err, row) {     
   if (err) {     
     return console.error(err.message);     
  }     
 res.render("editar.ejs", { dados: row });     
  });     
 });     
        
 // POST /edit/id    
 app.post("/editar/:id_m/:id_d", function (req, res) {    
 let id_m = req.params.id_m; //recebe parâmetro id da pagina editar.ejs  
 let id_d = req.params.id_d; //recebe parâmetro id da pagina editar.ejs  
  let dadosMestre = [req.body.Campo_mestre1,req.body.Campo_mestre2, id_m];  
 // POST /edit/id - UPDATE tabs. mestre e detalhes   
  let sql1 = "UPDATE tabela_mestre SET Campo_mestre1=?,Campo_mestre2=? WHERE (ID_mestre = ?)";    
  const dadosDetalhe = [req.body.Atributo_detalhe1,req.body.Atributo_detalhe2,id_d ];  
  let sql2 = "UPDATE tabela_detalhes SET Atributo_detalhe1=?,Atributo_detalhe2=? WHERE (ID_detalhe = ?)";    
 db.run(sql1, dadosMestre, function (err) {   
   if (err) {   
 return console.error(err.message);   
 }   
 });   
       
  
 db.run(sql2, dadosDetalhe, function (err) {   
 if (err) {   
 return console.error(err.message);   
 }   
 res.redirect("/");   
 });   
 });   
        
 // (4)GET /consulta em mestre para inserirDetalhe   
 app.get("/inserirD/:id_m/:id_d", (req, res) => {   
 let idm = req.params.id_m;   
 let idd = req.params.id_d;   
 let query = [idm, idd];   
 let sql = "SELECT * FROM tabela_mestre, tabela_detalhes WHERE (ID_mestre=FK_detalhe) and (ID_mestre =?) and (ID_detalhe =?)";  
 db.get(sql, query, function (err, row) {   
   if (err) {   
 return console.error(err.message);   
  }   
 res.render("inserirD.ejs", {    
 dado: row,   
  ID_detalhe : "",   
  Atributo_detalhe1 : "",   
  Atributo_detalhe2 : "",   
  FK_detalhe : "",   
  });   
  });   
    
 app.post("/inserirD/:id_m/:id_d", (req, res) => {  
     let idm = req.params.id_m;  
     let idd = req.params.id_d;  
  let sql3 = "INSERT INTO tabela_detalhes (Atributo_detalhe1,Atributo_detalhe2,FK_detalhe) VALUES (  ?, ?, ? )";  
     //insere chave PK (idm) de mestre na chave FK de detalhes (FK_detalhe)  
  const dadosDetalhe = [req.body.Atributo_detalhe1,req.body.Atributo_detalhe2,idm,];  
     db.run(sql3, dadosDetalhe, function (err) {  
       if (err) {  
         return console.error(err.message);  
       }  
       res.redirect("/");  
     });  
     });  
   }); //fim do escolpo do app.get inserirDetalhe  
        
 // (4)GET /delete/5  
 app.get("/delete/:id_m/:id_d", function (req, res) {  
     const idm = req.params.id_m;  
     const idd = req.params.id_d;  
     const query = [idm, idd];  
 let sql = "SELECT * FROM tabela_mestre, tabela_detalhes WHERE (ID_mestre=FK_detalhe) and (ID_mestre =?) and (ID_detalhe =?)";  
     db.get(sql, query, function (err, row) {  
       if (err) {  
         return console.error(err.message);  
       }  
       res.render("delete.ejs", { dados: row });  
     });  
   });  
        
 // POST /delete/5   
 app.post("/delete/:id_d", function (req, res) {   
     const idd = req.params.id_d;   
     const sql = "DELETE FROM tabela_detalhes WHERE ID_detalhe = ?";   
     db.run(sql, idd, function (err) {   
       if (err) {   
         return console.error(err.message);   
       }   
       res.redirect("/");   
     });   
   });   
      
   // GET /delete mestre e seus detalhesLS   
   app.get("/deletaTodos/:id_m", function (req, res) {   
     const idm = req.params.id_m;   
     const sql = "DELETE FROM tabela_mestre WHERE ID_mestre = ?";   
     db.run(sql, idm, function (err) {   
       if (err) {   
         return console.error(err.message);   
       }   
       res.redirect("/");   
     });   
   });   
        
   //instacia o servidor na porta 8080   
   app.listen(8080, () => {   
       console.log("SERVIDOR ativo. Acesse http://localhost:8080");   
   });  